package application;

public class Request {
	 Integer requestID;
	 String startDate; 
	 String computerTechType;
	 String computerTechModel;
	 String problemDescryption;
	 String requestStatus;
	 String completionDate;
	 String repairParts;
	 Integer masterID;
	 Integer clientID;
	public Integer getRequestID() {
		return requestID;
	}
	public void setRequestID(Integer requestID) {
		this.requestID = requestID;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getComputerTechType() {
		return computerTechType;
	}
	public void setComputerTechType(String computerTechType) {
		this.computerTechType = computerTechType;
	}
	public String getComputerTechModel() {
		return computerTechModel;
	}
	public void setComputerTechModel(String computerTechModel) {
		this.computerTechModel = computerTechModel;
	}
	public String getProblemDescryption() {
		return problemDescryption;
	}
	public void setProblemDescryption(String problemDescryption) {
		this.problemDescryption = problemDescryption;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}
	public String getRepairParts() {
		return repairParts;
	}
	public void setRepairParts(String repairParts) {
		this.repairParts = repairParts;
	}
	public Integer getMasterID() {
		return masterID;
	}
	public void setMasterID(Integer masterID) {
		this.masterID = masterID;
	}
	public Integer getClientID() {
		return clientID;
	}
	public void setClientID(Integer clientID) {
		this.clientID = clientID;
	}
	public Request() {
		super();
	}
	public Request(String startDate, String computerTechType, String computerTechModel, String problemDescryption,
			String requestStatus, String completionDate, String repairParts, Integer masterID, Integer clientID) {
		super();
		this.startDate = startDate;
		this.computerTechType = computerTechType;
		this.computerTechModel = computerTechModel;
		this.problemDescryption = problemDescryption;
		this.requestStatus = requestStatus;
		this.completionDate = completionDate;
		this.repairParts = repairParts;
		this.masterID = masterID;
		this.clientID = clientID;
	}
	
	
}
