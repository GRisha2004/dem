package application;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mysql.cj.jdbc.MysqlDataSource;

public class RequestDao {
	JdbcTemplate jb;
	
	List<Request> getAll(){
		List<Request> zavk = jb.query("select * from datarequests",
				(resultSet ,rowNum) -> {
					Request zav = new Request();
					zav.setRequestID(resultSet.getInt("requestID"));
					zav.setStartDate(resultSet.getString("startDate"));
					zav.setComputerTechType(resultSet.getString("computerTechType"));
					zav.setComputerTechModel(resultSet.getString("computerTechModel"));
					zav.setProblemDescryption(resultSet.getString("problemDescryption"));
					zav.setRequestStatus(resultSet.getString("requestStatus"));
					zav.setCompletionDate(resultSet.getString("completionDate"));
					zav.setRepairParts(resultSet.getString("repairParts"));
					zav.setMasterID(resultSet.getInt("masterID"));
					zav.setClientID(resultSet.getInt("clientID"));
					return zav;
		});
		return zavk;
	}
	

	
	
	
	
	public RequestDao (MysqlDataSource data) {
		super();
		jb = new JdbcTemplate(data);
		
	}
}
